package dev.emin.okan.javagame;



public class Launcher {
	
	public static void main(String[]args) {
		Game game =new Game ("Java Game !", 400,400);
		 game.start();
	} 
 
}
