Beginning in episode 34 of the New Beginner Java Game Programming Tutorial
Series by CodeNMore, some art was replaced with either:

a) Viewer-submitted art
or
b) CC0 art from OpenGameArt.org
	(license: https://creativecommons.org/publicdomain/zero/1.0/)
or
c) Original art by CodeNMore

All CC0 art used was provided from the following links:

- http://opengameart.org/content/base-character-spritesheet-16x16
- http://opengameart.org/content/old-frogatto-tile-art
- http://opengameart.org/content/dungeon-crawl-32x32-tiles

All art submitted by viewers is credited below:

- No viewer art has been used as of this episode

The font that is being used can be found at:
https://www.fontsquirrel.com/fonts/Silkscreen

All original artwork by CodeNMore within the New Beginner Java Game
Programming Tutorial Series is under the CC0 license:
https://creativecommons.org/publicdomain/zero/1.0/